// $Id: Connection_Recycling_Strategy.cpp 91287 2010-08-05 10:30:49Z johnnyw $

#include "ace/Connection_Recycling_Strategy.h"

ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_Connection_Recycling_Strategy::~ACE_Connection_Recycling_Strategy (void)
{
}

ACE_END_VERSIONED_NAMESPACE_DECL
