// $Id: config-macosx-mountainlion.h 96710 2013-01-28 07:56:36Z johnnyw $
#ifndef ACE_CONFIG_MACOSX_MOUNTAINLION_H
#define ACE_CONFIG_MACOSX_MOUNTAINLION_H

#include "ace/config-macosx-lion.h"

#endif // ACE_CONFIG_MACOSX_MOUNTAIN_LION_H
