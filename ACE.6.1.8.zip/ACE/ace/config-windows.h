/* -*- C++ -*- */
// $Id: config-windows.h 94353 2011-07-30 13:13:13Z johnnyw $

// This is all we need to do to build ACE on a Windows platform (32bit or 64bit)
#include "config-win32.h"
